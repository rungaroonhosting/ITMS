@extends('layouts.app')

@section('title', 'เพิ่มพนักงานใหม่')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('employees.index') }}">จัดการพนักงาน</a></li>
    <li class="breadcrumb-item active">เพิ่มพนักงานใหม่</li>
@endsection

@section('content')
<!-- Page Header -->
<div class="row mb-4">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3 mb-0 text-primary fw-bold">
                    <i class="fas fa-user-plus me-2"></i>เพิ่มพนักงานใหม่
                </h1>
                <p class="text-muted mb-0">กรอกข้อมูลพนักงานใหม่เข้าระบบ</p>
            </div>
            <a href="{{ route('employees.index') }}" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i>กลับ
            </a>
        </div>
    </div>
</div>

<!-- Form -->
<form id="employeeForm" action="{{ route('employees.store') }}" method="POST">
    @csrf
    
    <!-- ข้อมูลพื้นฐาน -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <i class="fas fa-user me-2"></i>ข้อมูลพื้นฐาน
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <!-- รหัสพนักงาน -->
                <div class="col-md-6">
                    <label for="employee_code" class="form-label">รหัสพนักงาน</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('employee_code') is-invalid @enderror" 
                               id="employee_code" name="employee_code" value="{{ old('employee_code') }}" 
                               placeholder="สร้างอัตโนมัติ" readonly>
                        <button type="button" class="btn btn-outline-primary" id="generateEmployeeCodeBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                    </div>
                    <div class="form-text">รหัสจะถูกสร้างอัตโนมัติ เช่น EMP001</div>
                    @error('employee_code')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- ID Keycard -->
                <div class="col-md-6">
                    <label for="keycard_id" class="form-label">ID Keycard</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('keycard_id') is-invalid @enderror" 
                               id="keycard_id" name="keycard_id" value="{{ old('keycard_id') }}" 
                               placeholder="สร้างอัตโนมัติ" readonly>
                        <button type="button" class="btn btn-outline-primary" id="generateKeycardBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                    </div>
                    <div class="form-text">รหัสบัตรจะถูกสร้างอัตโนมัติ เช่น KC123456</div>
                    @error('keycard_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- ชื่อภาษาไทย -->
                <div class="col-md-6">
                    <label for="first_name_th" class="form-label required">ชื่อภาษาไทย</label>
                    <input type="text" class="form-control @error('first_name_th') is-invalid @enderror" 
                           id="first_name_th" name="first_name_th" value="{{ old('first_name_th') }}" 
                           placeholder="กรอกชื่อภาษาไทย" required>
                    @error('first_name_th')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- นามสกุลภาษาไทย -->
                <div class="col-md-6">
                    <label for="last_name_th" class="form-label required">นามสกุลภาษาไทย</label>
                    <input type="text" class="form-control @error('last_name_th') is-invalid @enderror" 
                           id="last_name_th" name="last_name_th" value="{{ old('last_name_th') }}" 
                           placeholder="กรอกนามสกุลภาษาไทย" required>
                    @error('last_name_th')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- ชื่อภาษาอังกฤษ -->
                <div class="col-md-6">
                    <label for="first_name_en" class="form-label required">ชื่อภาษาอังกฤษ</label>
                    <input type="text" class="form-control @error('first_name_en') is-invalid @enderror" 
                           id="first_name_en" name="first_name_en" value="{{ old('first_name_en') }}" 
                           placeholder="First Name" required>
                    @error('first_name_en')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- นามสกุลภาษาอังกฤษ -->
                <div class="col-md-6">
                    <label for="last_name_en" class="form-label required">นามสกุลภาษาอังกฤษ</label>
                    <input type="text" class="form-control @error('last_name_en') is-invalid @enderror" 
                           id="last_name_en" name="last_name_en" value="{{ old('last_name_en') }}" 
                           placeholder="Last Name" required>
                    @error('last_name_en')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- ชื่อเล่น -->
                <div class="col-md-6">
                    <label for="nickname" class="form-label">ชื่อเล่น</label>
                    <input type="text" class="form-control @error('nickname') is-invalid @enderror" 
                           id="nickname" name="nickname" value="{{ old('nickname') }}" 
                           placeholder="กรอกชื่อเล่น">
                    @error('nickname')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <!-- ข้อมูลระบบคอมพิวเตอร์ -->
    <div class="card mb-4">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-desktop me-2"></i>ข้อมูลระบบคอมพิวเตอร์
                </h5>
                <button type="button" class="btn btn-primary btn-sm" id="generateAllComputerBtn">
                    <i class="fas fa-magic me-1"></i>สร้างอัตโนมัติทั้งหมด
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <!-- Username -->
                <div class="col-md-6">
                    <label for="username" class="form-label">Username (เปิดคอมพิวเตอร์)</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('username') is-invalid @enderror" 
                               id="username" name="username" value="{{ old('username') }}" 
                               placeholder="สร้างจากชื่ออังกฤษ">
                        <button type="button" class="btn btn-outline-primary" id="generateUsernameBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                    </div>
                    <div class="form-text">จะถูกสร้างจากชื่อ.นามสกุล ภาษาอังกฤษ</div>
                    @error('username')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- Password คอมพิวเตอร์ -->
                <div class="col-md-6">
                    <label for="computer_password" class="form-label">Password (เปิดคอมพิวเตอร์)</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('computer_password') is-invalid @enderror" 
                               id="computer_password" name="computer_password" value="{{ old('computer_password') }}" 
                               placeholder="Random 10 ตัวอักษร">
                        <button type="button" class="btn btn-outline-primary" id="generateComputerPasswordBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                        @if(auth()->user()->canViewPasswords())
                            <button type="button" class="btn btn-outline-info" id="toggleComputerPasswordBtn">
                                <i class="fas fa-eye"></i>
                            </button>
                        @endif
                    </div>
                    <div class="form-text">รหัสผ่านสำหรับเปิดคอมพิวเตอร์</div>
                    @error('computer_password')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- รหัสเครื่องถ่ายเอกสาร -->
                <div class="col-md-6">
                    <label for="copier_code" class="form-label">รหัสเครื่องถ่ายเอกสาร</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('copier_code') is-invalid @enderror" 
                               id="copier_code" name="copier_code" value="{{ old('copier_code') }}" 
                               placeholder="Random 4 หลัก" maxlength="4">
                        <button type="button" class="btn btn-outline-primary" id="generateCopierCodeBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                    </div>
                    <div class="form-text">รหัส 4 หลักสำหรับใช้เครื่องถ่ายเอกสาร</div>
                    @error('copier_code')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <!-- ข้อมูลระบบอีเมล -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <i class="fas fa-envelope me-2"></i>ข้อมูลระบบอีเมล
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <!-- Email -->
                <div class="col-md-8">
                    <label for="email" class="form-label">อีเมล</label>
                    <div class="input-group">
                        <input type="email" class="form-control @error('email') is-invalid @enderror" 
                               id="email" name="email" value="{{ old('email') }}" 
                               placeholder="สร้างจาก Username">
                        <select class="form-select" id="email_domain" style="max-width: 200px;">
                            <option value="bettersystem.co.th">@bettersystem.co.th</option>
                            <option value="better-groups.com">@better-groups.com</option>
                        </select>
                        <button type="button" class="btn btn-outline-primary" id="generateEmailBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                    </div>
                    <div class="form-text">อีเมลจะถูกสร้างจาก Username + โดเมนที่เลือก</div>
                    @error('email')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- Password Email -->
                <div class="col-md-4">
                    <label for="email_password" class="form-label">Password อีเมล</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('email_password') is-invalid @enderror" 
                               id="email_password" name="email_password" value="{{ old('email_password') }}" 
                               placeholder="Random 10 ตัวอักษร">
                        <button type="button" class="btn btn-outline-primary" id="generateEmailPasswordBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                        @if(auth()->user()->canViewPasswords())
                            <button type="button" class="btn btn-outline-info" id="toggleEmailPasswordBtn">
                                <i class="fas fa-eye"></i>
                            </button>
                        @endif
                    </div>
                    @error('email_password')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <!-- ข้อมูลโปรแกรม Express -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <i class="fas fa-shipping-fast me-2"></i>ข้อมูลโปรแกรม Express
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <!-- Username Express -->
                <div class="col-md-6">
                    <label for="express_username" class="form-label">Username Express (7 ตัวอักษร)</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('express_username') is-invalid @enderror" 
                               id="express_username" name="express_username" value="{{ old('express_username') }}" 
                               placeholder="7 ตัวอักษร" maxlength="7">
                        <button type="button" class="btn btn-outline-primary" id="generateExpressUsernameBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                    </div>
                    <div class="form-text">สร้างจากชื่ออังกฤษ 7 ตัวอักษร</div>
                    @error('express_username')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- รหัส Express -->
                <div class="col-md-6">
                    <label for="express_code" class="form-label">รหัสโปรแกรม Express</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('express_code') is-invalid @enderror" 
                               id="express_code" name="express_code" value="{{ old('express_code') }}" 
                               placeholder="Random 4 หลัก" maxlength="4">
                        <button type="button" class="btn btn-outline-primary" id="generateExpressCodeBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                        @if(auth()->user()->canViewPasswords())
                            <button type="button" class="btn btn-outline-info" id="toggleExpressCodeBtn">
                                <i class="fas fa-eye"></i>
                            </button>
                        @endif
                    </div>
                    <div class="form-text">รหัส 4 หลักสำหรับโปรแกรม Express</div>
                    @error('express_code')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <!-- แผนกและสิทธิ์การใช้งาน -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <i class="fas fa-building me-2"></i>แผนกและสิทธิ์การใช้งาน
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <!-- แผนกการทำงาน -->
                <div class="col-md-12">
                    <label for="department_id" class="form-label required">แผนกการทำงาน</label>
                    <select class="form-select @error('department_id') is-invalid @enderror" 
                            id="department_id" name="department_id" required>
                        <option value="">เลือกแผนก</option>
                        @foreach(\App\Models\Employee::getDepartments() as $id => $name)
                            <option value="{{ $id }}" {{ old('department_id') == $id ? 'selected' : '' }}>
                                {{ $name }}
                            </option>
                        @endforeach
                    </select>
                    @if(auth()->user()->isSuperAdmin())
                        <div class="form-text">Super Admin สามารถเพิ่ม/ลบแผนกได้ในภายหลัง</div>
                    @endif
                    @error('department_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <!-- สิทธิ์การใช้งาน -->
                <div class="col-md-6">
                    <label class="form-label">สิทธิ์การใช้งาน</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="can_print_color" 
                               name="can_print_color" value="1" {{ old('can_print_color') ? 'checked' : '' }}>
                        <label class="form-check-label" for="can_print_color">
                            <i class="fas fa-palette me-1"></i>สามารถปริ้นสีได้
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="can_use_vpn" 
                               name="can_use_vpn" value="1" {{ old('can_use_vpn') ? 'checked' : '' }}>
                        <label class="form-check-label" for="can_use_vpn">
                            <i class="fas fa-shield-alt me-1"></i>สามารถใช้งาน VPN ได้
                        </label>
                    </div>
                </div>

                <!-- สถานะและบทบาท -->
                <div class="col-md-3">
                    <label for="status" class="form-label required">สถานะ</label>
                    <select class="form-select @error('status') is-invalid @enderror" 
                            id="status" name="status" required>
                        @foreach(\App\Models\Employee::getStatuses() as $key => $value)
                            <option value="{{ $key }}" {{ old('status', 'active') == $key ? 'selected' : '' }}>
                                {{ $value }}
                            </option>
                        @endforeach
                    </select>
                    @error('status')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-3">
                    <label for="role" class="form-label required">บทบาท</label>
                    <select class="form-select @error('role') is-invalid @enderror" 
                            id="role" name="role" required>
                        @foreach(\App\Models\Employee::getRoles() as $key => $value)
                            <option value="{{ $key }}" {{ old('role', 'employee') == $key ? 'selected' : '' }}>
                                {{ $value }}
                            </option>
                        @endforeach
                    </select>
                    @error('role')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <!-- ระบบ Login -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">
                <i class="fas fa-key me-2"></i>ระบบ Login
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="login_email" class="form-label">Email สำหรับ Login</label>
                    <input type="email" class="form-control" id="login_email" 
                           placeholder="จะใช้อีเมลเดียวกันข้างต้น" readonly>
                    <div class="form-text">จะใช้อีเมลเดียวกันกับที่สร้างข้างต้น</div>
                </div>
                
                <div class="col-md-6">
                    <label for="password" class="form-label">Password สำหรับ Login ระบบ</label>
                    <div class="input-group">
                        <input type="text" class="form-control @error('password') is-invalid @enderror" 
                               id="password" name="password" value="{{ old('password') }}" 
                               placeholder="Random 10 ตัวอักษร">
                        <button type="button" class="btn btn-outline-primary" id="generateLoginPasswordBtn">
                            <i class="fas fa-magic"></i>
                        </button>
                        @if(auth()->user()->canViewPasswords())
                            <button type="button" class="btn btn-outline-info" id="toggleLoginPasswordBtn">
                                <i class="fas fa-eye"></i>
                            </button>
                        @endif
                    </div>
                    <div class="form-text">รหัสผ่านสำหรับเข้าระบบ IT Management</div>
                    @error('password')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <a href="{{ route('employees.index') }}" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-1"></i>ยกเลิก
                </a>
                <div>
                    <button type="button" class="btn btn-info me-2" id="previewBtn">
                        <i class="fas fa-eye me-1"></i>ดูตัวอย่าง
                    </button>
                    <button type="button" class="btn btn-success me-2" id="generateAllBtn">
                        <i class="fas fa-magic me-1"></i>สร้างทั้งหมดอัตโนมัติ
                    </button>
                    <button type="submit" class="btn btn-primary" id="submitBtn">
                        <i class="fas fa-save me-1"></i>บันทึกข้อมูล
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-eye me-2"></i>ตัวอย่างข้อมูลพนักงาน
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="previewContent">
                <!-- Preview content -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                <button type="button" class="btn btn-primary" onclick="$('#employeeForm').submit()">
                    <i class="fas fa-save me-1"></i>ยืนยันและบันทึก
                </button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    // Auto-generate functions
    function generateEmployeeCode() {
        $.get('{{ route("employees.generateData") }}', { type: 'employee_code' })
            .done(function(data) {
                $('#employee_code').val(data.employee_code);
            });
    }

    function generateKeycard() {
        $.get('{{ route("employees.generateData") }}', { type: 'keycard_id' })
            .done(function(data) {
                $('#keycard_id').val(data.keycard_id);
            });
    }

    function generateUsername() {
        const firstNameEn = $('#first_name_en').val();
        const lastNameEn = $('#last_name_en').val();
        
        if (firstNameEn && lastNameEn) {
            $.get('{{ route("employees.generateData") }}', { 
                type: 'username', 
                first_name_en: firstNameEn, 
                last_name_en: lastNameEn 
            }).done(function(data) {
                $('#username').val(data.username);
                generateEmail(); // Auto-generate email when username changes
            });
        }
    }

    function generateEmail() {
        const firstNameEn = $('#first_name_en').val();
        const lastNameEn = $('#last_name_en').val();
        const domain = $('#email_domain').val();
        
        if (firstNameEn && lastNameEn) {
            $.get('{{ route("employees.generateData") }}', { 
                type: 'email', 
                first_name_en: firstNameEn, 
                last_name_en: lastNameEn,
                domain: domain
            }).done(function(data) {
                $('#email').val(data.email);
                $('#login_email').val(data.email);
            });
        }
    }

    function generatePassword(field) {
        $.get('{{ route("employees.generateData") }}', { type: 'password' })
            .done(function(data) {
                $('#' + field).val(data.password);
            });
    }

    function generateCopierCode() {
        $.get('{{ route("employees.generateData") }}', { type: 'copier_code' })
            .done(function(data) {
                $('#copier_code').val(data.copier_code);
            });
    }

    function generateExpressUsername() {
        const firstNameEn = $('#first_name_en').val();
        const lastNameEn = $('#last_name_en').val();
        
        if (firstNameEn && lastNameEn) {
            $.get('{{ route("employees.generateData") }}', { 
                type: 'express_username', 
                first_name_en: firstNameEn, 
                last_name_en: lastNameEn 
            }).done(function(data) {
                $('#express_username').val(data.express_username);
            });
        }
    }

    function generateExpressCode() {
        $.get('{{ route("employees.generateData") }}', { type: 'express_code' })
            .done(function(data) {
                $('#express_code').val(data.express_code);
            });
    }

    // Button event handlers
    $('#generateEmployeeCodeBtn').click(generateEmployeeCode);
    $('#generateKeycardBtn').click(generateKeycard);
    $('#generateUsernameBtn').click(generateUsername);
    $('#generateEmailBtn').click(generateEmail);
    $('#generateComputerPasswordBtn').click(() => generatePassword('computer_password'));
    $('#generateEmailPasswordBtn').click(() => generatePassword('email_password'));
    $('#generateLoginPasswordBtn').click(() => generatePassword('password'));
    $('#generateCopierCodeBtn').click(generateCopierCode);
    $('#generateExpressUsernameBtn').click(generateExpressUsername);
    $('#generateExpressCodeBtn').click(generateExpressCode);

    // Generate all computer data
    $('#generateAllComputerBtn').click(function() {
        generateUsername();
        generatePassword('computer_password');
        generateCopierCode();
    });

    // Generate everything
    $('#generateAllBtn').click(function() {
        generateEmployeeCode();
        generateKeycard();
        if ($('#first_name_en').val() && $('#last_name_en').val()) {
            generateUsername();
            generateExpressUsername();
        }
        generatePassword('computer_password');
        generatePassword('email_password');
        generatePassword('password');
        generateCopierCode();
        generateExpressCode();
    });

    // Auto-generate when English names change
    $('#first_name_en, #last_name_en').on('blur', function() {
        if ($('#first_name_en').val() && $('#last_name_en').val()) {
            if (!$('#username').val()) generateUsername();
            if (!$('#express_username').val()) generateExpressUsername();
        }
    });

    // Email domain change
    $('#email_domain').change(generateEmail);

    // Password visibility toggles
    $('.btn-outline-info').click(function() {
        const targetId = $(this).attr('id').replace('toggle', '').replace('Btn', '').toLowerCase();
        const targetField = $('#' + targetId.replace('login', '') + (targetId.includes('login') ? 'password' : ''));
        const icon = $(this).find('i');
        
        if (targetField.attr('type') === 'password') {
            targetField.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            targetField.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });

    // Form submission
    $('#employeeForm').on('submit', function(e) {
        e.preventDefault();
        
        const submitBtn = $('#submitBtn');
        const originalText = submitBtn.html();
        
        submitBtn.prop('disabled', true)
                 .html('<i class="fas fa-spinner fa-spin me-1"></i>กำลังบันทึก...');

        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'สำเร็จ!',
                        text: response.message,
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        window.location.href = response.redirect || '{{ route("employees.index") }}';
                    });
                }
            },
            error: function(xhr) {
                const response = xhr.responseJSON;
                
                if (response.errors) {
                    Object.keys(response.errors).forEach(function(field) {
                        const input = $(`[name="${field}"]`);
                        input.addClass('is-invalid');
                        input.siblings('.invalid-feedback').remove();
                        input.after(`<div class="invalid-feedback">${response.errors[field][0]}</div>`);
                    });
                }
                
                Swal.fire({
                    title: 'เกิดข้อผิดพลาด!',
                    text: response.message || 'ไม่สามารถบันทึกข้อมูลได้',
                    icon: 'error'
                });
            },
            complete: function() {
                submitBtn.prop('disabled', false).html(originalText);
            }
        });
    });

    // Auto-generate initial data
    generateEmployeeCode();
    generateKeycard();
});
</script>
@endpush
