<?php $__env->startSection('title', 'จัดการข้อมูลพนักงาน'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css">
<link rel="stylesheet" href="<?php echo e(asset('css/employees.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-primary-red fw-bold">
                <i class="fas fa-users me-2"></i>จัดการข้อมูลพนักงาน
            </h1>
            <p class="text-muted mb-0">
                จัดการข้อมูลพนักงานทั้งหมดในระบบ
            </p>
        </div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-success" id="exportBtn">
                <i class="fas fa-file-excel me-1"></i>ส่งออก Excel
            </button>
            <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-primary-red">
                <i class="fas fa-plus me-1"></i>เพิ่มพนักงานใหม่
            </a>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="stat-icon bg-primary-red">
                                <i class="fas fa-users text-white"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <div class="stat-number"><?php echo e(\App\Models\Employee::count()); ?></div>
                            <div class="stat-label">พนักงานทั้งหมด</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="stat-icon bg-success">
                                <i class="fas fa-user-check text-white"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <div class="stat-number"><?php echo e(\App\Models\Employee::where('status', 'active')->count()); ?></div>
                            <div class="stat-label">พนักงานใช้งาน</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="stat-icon bg-warning">
                                <i class="fas fa-building text-white"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <div class="stat-number"><?php echo e(count(\App\Models\Employee::getDepartments())); ?></div>
                            <div class="stat-label">แผนกทั้งหมด</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="stat-icon bg-info">
                                <i class="fas fa-calendar-plus text-white"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <div class="stat-number"><?php echo e(\App\Models\Employee::whereMonth('hire_date', now()->month)->count()); ?></div>
                            <div class="stat-label">เข้าใหม่เดือนนี้</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-gradient-primary text-white">
            <h5 class="card-title mb-0">
                <i class="fas fa-search me-2"></i>ค้นหาและกรองข้อมูล
            </h5>
        </div>
        <div class="card-body">
            <form id="filterForm" method="GET">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label for="search" class="form-label">ค้นหา</label>
                        <input type="text" class="form-control" id="search" name="search" 
                               value="<?php echo e($request->search); ?>" 
                               placeholder="รหัส, ชื่อ, อีเมล...">
                    </div>
                    <div class="col-md-3">
                        <label for="department" class="form-label">แผนก</label>
                        <select class="form-select" id="department" name="department">
                            <option value="">ทั้งหมด</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($request->department == $key ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="status" class="form-label">สถานะ</label>
                        <select class="form-select" id="status" name="status">
                            <option value="">ทั้งหมด</option>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($request->status == $key ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="role" class="form-label">บทบาท</label>
                        <select class="form-select" id="role" name="role">
                            <option value="">ทั้งหมด</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($request->role == $key ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary-red me-2">
                            <i class="fas fa-search me-1"></i>ค้นหา
                        </button>
                        <button type="button" class="btn btn-outline-secondary" id="clearFilter">
                            <i class="fas fa-times me-1"></i>ล้างตัวกรอง
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-bottom">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">
                    <i class="fas fa-list me-2 text-primary-red"></i>รายการพนักงาน
                </h5>
                <div class="d-flex align-items-center gap-2">
                    <small class="text-muted">
                        แสดงผล <?php echo e($employees->firstItem() ?? 0); ?>-<?php echo e($employees->lastItem() ?? 0); ?> 
                        จาก <?php echo e($employees->total()); ?> รายการ
                    </small>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="employeesTable">
                    <thead class="table-light">
                        <tr>
                            <th width="10%">รหัสพนักงาน</th>
                            <th width="20%">ชื่อ-นามสกุล</th>
                            <th width="15%">อีเมล</th>
                            <th width="12%">แผนก</th>
                            <th width="15%">ตำแหน่ง</th>
                            <th width="8%">สถานะ</th>
                            <th width="10%">บทบาท</th>
                            <th width="10%" class="text-center">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <span class="fw-bold text-primary-red"><?php echo e($employee->employee_id); ?></span>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar-sm bg-light rounded-circle d-flex align-items-center justify-content-center me-2">
                                        <i class="fas fa-user text-muted"></i>
                                    </div>
                                    <div>
                                        <div class="fw-semibold"><?php echo e($employee->full_name); ?></div>
                                        <small class="text-muted"><?php echo e($employee->username); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <a href="mailto:<?php echo e($employee->email); ?>" class="text-decoration-none">
                                    <?php echo e($employee->email); ?>

                                </a>
                            </td>
                            <td><?php echo e($employee->department_text); ?></td>
                            <td><?php echo e($employee->position); ?></td>
                            <td>
                                <?php if($employee->status == 'active'): ?>
                                    <span class="badge bg-success"><?php echo e($employee->status_text); ?></span>
                                <?php elseif($employee->status == 'inactive'): ?>
                                    <span class="badge bg-warning"><?php echo e($employee->status_text); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><?php echo e($employee->status_text); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($employee->role == 'super_admin'): ?>
                                    <span class="badge bg-danger"><?php echo e($employee->role_text); ?></span>
                                <?php elseif($employee->role == 'it_admin'): ?>
                                    <span class="badge bg-warning"><?php echo e($employee->role_text); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-info"><?php echo e($employee->role_text); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('employees.show', $employee)); ?>" 
                                       class="btn btn-sm btn-outline-info" title="ดูรายละเอียด">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('employees.edit', $employee)); ?>" 
                                       class="btn btn-sm btn-outline-warning" title="แก้ไข">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button class="btn btn-sm btn-outline-danger delete-btn" 
                                            data-id="<?php echo e($employee->id); ?>" 
                                            data-name="<?php echo e($employee->full_name); ?>" 
                                            title="ลบ">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">
                                <div class="empty-state">
                                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                    <h5 class="text-muted">ไม่พบข้อมูลพนักงาน</h5>
                                    <p class="text-muted">ลองปรับเปลี่ยนเงื่อนไขการค้นหา หรือ 
                                        <a href="<?php echo e(route('employees.create')); ?>" class="text-decoration-none">เพิ่มพนักงานใหม่</a>
                                    </p>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <?php if($employees->hasPages()): ?>
            <div class="d-flex justify-content-between align-items-center mt-4">
                <div>
                    <small class="text-muted">
                        แสดงผล <?php echo e($employees->firstItem()); ?>-<?php echo e($employees->lastItem()); ?> 
                        จาก <?php echo e($employees->total()); ?> รายการ
                    </small>
                </div>
                <div>
                    <?php echo e($employees->appends(request()->query())->links()); ?>

                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('js/employees.js')); ?>"></script>

<script>
$(document).ready(function() {
    // Clear filter functionality
    $('#clearFilter').click(function() {
        window.location.href = '<?php echo e(route("employees.index")); ?>';
    });

    // Export Excel functionality
    $('#exportBtn').click(function() {
        const params = new URLSearchParams();
        
        if ($('#search').val()) params.append('search', $('#search').val());
        if ($('#department').val()) params.append('department', $('#department').val());
        if ($('#status').val()) params.append('status', $('#status').val());
        if ($('#role').val()) params.append('role', $('#role').val());
        
        const url = '<?php echo e(route("employees.exportExcel")); ?>' + (params.toString() ? '?' + params.toString() : '');
        window.location.href = url;
    });

    // Delete functionality
    $(document).on('click', '.delete-btn', function() {
        const employeeId = $(this).data('id');
        const employeeName = $(this).data('name');

        Swal.fire({
            title: 'ยืนยันการลบ',
            text: `คุณต้องการลบพนักงาน "${employeeName}" หรือไม่?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'ลบ',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: `/employees/${employeeId}`,
                    type: 'DELETE',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire({
                                title: 'สำเร็จ!',
                                text: response.message,
                                icon: 'success',
                                timer: 2000,
                                showConfirmButton: false
                            }).then(() => {
                                location.reload();
                            });
                        }
                    },
                    error: function(xhr) {
                        const response = xhr.responseJSON;
                        Swal.fire({
                            title: 'เกิดข้อผิดพลาด!',
                            text: response?.message || 'ไม่สามารถลบข้อมูลได้',
                            icon: 'error'
                        });
                    }
                });
            }
        });
    });

    // Auto submit form on filter change
    $('#department, #status, #role').change(function() {
        $('#filterForm').submit();
    });

    // Search with delay
    let searchTimeout;
    $('#search').on('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            $('#filterForm').submit();
        }, 500);
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/itms/resources/views/employees/index.blade.php ENDPATH**/ ?>