<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\EmployeeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Redirect root to appropriate dashboard
Route::get('/', function () {
    if (Auth::check()) {
        return redirect('/dashboard');
    }
    return redirect('/login');
});

/*
|--------------------------------------------------------------------------
| Authentication Routes
|--------------------------------------------------------------------------
*/

// Login Routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/loginWeb', [AuthController::class, 'loginWeb'])->name('login.web');

// Password Reset Routes (Simple)
Route::get('/forgot-password', function () {
    return redirect('/login')->with('info', 'กรุณาติดต่อผู้ดูแลระบบสำหรับการรีเซ็ตรหัสผ่าน');
})->name('password.request');

Route::post('/forgot-password', function () {
    return back()->with('status', 'Password reset link sent to your email!');
})->name('password.email');

// Logout Routes
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::post('/logoutWeb', [AuthController::class, 'logoutWeb'])->name('logout.web');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout.get');

/*
|--------------------------------------------------------------------------
| Protected Routes (ต้อง login ก่อน)
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->group(function () {
    
    // Dashboard Routes
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
    
    Route::get('/admin/dashboard', function () {
        return view('admin.dashboard');
    })->name('admin.dashboard');
    
    Route::get('/manager/dashboard', function () {
        return view('manager.dashboard');
    })->name('manager.dashboard');

    // Employee Management Routes - ลบ middleware ที่ขัดขวาง
    Route::resource('employees', EmployeeController::class);
    
    // Additional Employee Routes
    Route::post('/employees/{id}/restore', [EmployeeController::class, 'restore'])->name('employees.restore');
    Route::delete('/employees/{id}/force-delete', [EmployeeController::class, 'forceDelete'])->name('employees.force-delete');
    //Route::get('/employees/export/excel', [EmployeeController::class, 'exportExcel'])->name('employees.export.excel');
    Route::get('/employees/export-excel', [EmployeeController::class, 'exportExcel'])->name('employees.exportExcel');
Route::get('/employees/generate/data', [EmployeeController::class, 'generateData'])->name('employees.generate.data');
    
});

/*
|--------------------------------------------------------------------------
| API Routes (ถ้ามี)
|--------------------------------------------------------------------------
*/

Route::prefix('api')->group(function () {
    Route::post('/auth/login', [AuthController::class, 'login']);
    Route::post('/auth/logout', [AuthController::class, 'logout']);
});

/*
|--------------------------------------------------------------------------
| Test Routes (for debugging)
|--------------------------------------------------------------------------
*/

// Test Employee Route (No Middleware)
Route::get('/test-employees', function() {
    $employees = \App\Models\Employee::paginate(15);
    return view('employees.index', [
        'employees' => $employees,
        'departments' => \App\Models\Employee::getDepartments(),
        'statuses' => \App\Models\Employee::getStatuses(),
        'roles' => \App\Models\Employee::getRoles(),
        'request' => request()
    ]);
})->name('test.employees');

/*
|--------------------------------------------------------------------------
| Fallback Route
|--------------------------------------------------------------------------
*/

Route::fallback(function () {
    if (Auth::check()) {
        return redirect('/dashboard');
    }
    
    try {
        return view('errors.404')->with('status', 404);
    } catch (\Exception $e) {
        return redirect('/login')->with('error', 'Page not found');
    }
});
