<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class Employee extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        // ข้อมูลเก่า (รองรับ backward compatibility)
        'name',
        'email', 
        'department',
        'role',
        'status',
        'position',
        'hire_date',
        'salary',
        'phone',
        'address',
        'emergency_contact',
        'emergency_phone',
        'notes',
        
        // ข้อมูลใหม่ตามความต้องการ
        'employee_code',
        'keycard_id',
        'first_name_th',
        'last_name_th',
        'first_name_en',
        'last_name_en',
        'nickname',
        'username',
        'computer_password',
        'copier_code',
        'email_password',
        'department_id',
        'express_username',
        'express_code',
        'can_print_color',
        'can_use_vpn',
        'password', // สำหรับ login ระบบ
    ];

    protected $hidden = [
        'password',
        'remember_token',
        'computer_password',
        'email_password',
        'express_code',
    ];

    protected $casts = [
        'can_print_color' => 'boolean',
        'can_use_vpn' => 'boolean',
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'hire_date' => 'date',
    ];

    // Relationships
    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    // Accessors สำหรับ backward compatibility
    public function getFullNameThAttribute()
    {
        if ($this->first_name_th && $this->last_name_th) {
            return $this->first_name_th . ' ' . $this->last_name_th;
        }
        return $this->name ?? 'ไม่ระบุชื่อ';
    }

    public function getFullNameEnAttribute()
    {
        if ($this->first_name_en && $this->last_name_en) {
            return $this->first_name_en . ' ' . $this->last_name_en;
        }
        return $this->name ?? 'Unknown';
    }

    public function getInitialsAttribute()
    {
        if ($this->first_name_en && $this->last_name_en) {
            return strtoupper(substr($this->first_name_en, 0, 1) . substr($this->last_name_en, 0, 1));
        }
        return strtoupper(substr($this->name ?? 'UN', 0, 2));
    }

    public function getDepartmentNameAttribute()
    {
        if ($this->department) {
            return $this->department->name;
        }
        return $this->department ?? 'ไม่ระบุแผนก';
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeByDepartment($query, $departmentId)
    {
        if ($departmentId) {
            return $query->where('department_id', $departmentId);
        }
        return $query;
    }

    public function scopeByRole($query, $role)
    {
        return $query->where('role', $role);
    }

    public function scopeSearch($query, $search)
    {
        return $query->where(function ($q) use ($search) {
            $q->where('first_name_th', 'like', "%{$search}%")
              ->orWhere('last_name_th', 'like', "%{$search}%")
              ->orWhere('first_name_en', 'like', "%{$search}%")
              ->orWhere('last_name_en', 'like', "%{$search}%")
              ->orWhere('nickname', 'like', "%{$search}%")
              ->orWhere('employee_code', 'like', "%{$search}%")
              ->orWhere('email', 'like', "%{$search}%")
              ->orWhere('name', 'like', "%{$search}%"); // รองรับข้อมูลเก่า
        });
    }

    // Helper Methods
    public function canViewPasswords()
    {
        return in_array($this->role, ['super_admin', 'it_admin']);
    }

    public function isSuperAdmin()
    {
        return $this->role === 'super_admin';
    }

    public function isITAdmin()
    {
        return $this->role === 'it_admin';
    }

    public function isManager()
    {
        return $this->role === 'manager';
    }

    public function isEmployee()
    {
        return $this->role === 'employee';
    }

    public function getStatusBadgeClass()
    {
        return match($this->status) {
            'active' => 'bg-green-100 text-green-800',
            'inactive' => 'bg-gray-100 text-gray-800',
            'suspended' => 'bg-red-100 text-red-800',
            default => 'bg-gray-100 text-gray-800'
        };
    }

    public function getRoleBadgeClass()
    {
        return match($this->role) {
            'super_admin' => 'bg-red-100 text-red-800',
            'it_admin' => 'bg-blue-100 text-blue-800',
            'manager' => 'bg-yellow-100 text-yellow-800',
            'employee' => 'bg-gray-100 text-gray-800',
            default => 'bg-gray-100 text-gray-800'
        };
    }

    // Static Methods สำหรับ Dropdown Options
    public static function getDepartments()
    {
        // ใช้ข้อมูลจาก departments table ถ้ามี
        try {
            return \App\Models\Department::where('is_active', true)
                ->pluck('name', 'id')
                ->toArray();
        } catch (\Exception $e) {
            // fallback ถ้าไม่มี departments table
            return [
                1 => 'แผนกเทคโนโลยีสารสนเทศ',
                2 => 'แผนกบัญชี',
                3 => 'แผนกทรัพยากรบุคคล',
                4 => 'แผนกขาย',
            ];
        }
    }

    public static function getStatuses()
    {
        return [
            'active' => 'ใช้งาน',
            'inactive' => 'ไม่ใช้งาน',
            'suspended' => 'ระงับการใช้งาน',
        ];
    }

    public static function getRoles()
    {
        return [
            'super_admin' => 'Super Admin',
            'it_admin' => 'IT Admin',
            'manager' => 'Manager',
            'employee' => 'Employee',
        ];
    }

    public static function getEmailDomains()
    {
        try {
            return \App\Models\EmailDomain::where('is_active', true)
                ->orderBy('is_default', 'desc')
                ->pluck('domain', 'domain')
                ->toArray();
        } catch (\Exception $e) {
            // fallback ถ้าไม่มี email_domains table
            return [
                'bettersystem.co.th' => 'bettersystem.co.th',
                'better-groups.com' => 'better-groups.com',
            ];
        }
    }

    // Static Methods สำหรับ Generate ข้อมูลอัตโนมัติ
    public static function generateEmployeeCode()
    {
        $lastEmployee = self::whereNotNull('employee_code')->orderBy('id', 'desc')->first();
        if ($lastEmployee && $lastEmployee->employee_code) {
            $lastNumber = (int)substr($lastEmployee->employee_code, 3);
            $nextNumber = $lastNumber + 1;
        } else {
            $nextNumber = 1;
        }
        return 'EMP' . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);
    }

    public static function generateKeycardId()
    {
        do {
            $keycardId = 'KC' . rand(100000, 999999);
        } while (self::where('keycard_id', $keycardId)->exists());
        
        return $keycardId;
    }

    public static function generateUsername($firstNameEn, $lastNameEn)
    {
        $baseUsername = strtolower($firstNameEn . '.' . $lastNameEn);
        $username = $baseUsername;
        $counter = 1;
        
        while (self::where('username', $username)->exists()) {
            $username = $baseUsername . $counter;
            $counter++;
        }
        
        return $username;
    }

    public static function generatePassword()
    {
        $lowercase = 'abcdefghijklmnopqrstuvwxyz';
        $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $numbers = '0123456789';
        $special = '!@#$%^&*';
        
        $password = '';
        $password .= $lowercase[rand(0, strlen($lowercase) - 1)];
        $password .= $uppercase[rand(0, strlen($uppercase) - 1)];
        $password .= $numbers[rand(0, strlen($numbers) - 1)];
        $password .= $special[rand(0, strlen($special) - 1)];
        
        $allChars = $lowercase . $uppercase . $numbers . $special;
        for ($i = 0; $i < 6; $i++) {
            $password .= $allChars[rand(0, strlen($allChars) - 1)];
        }
        
        return str_shuffle($password);
    }

    public static function generateCopierCode()
    {
        do {
            $code = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
        } while (self::where('copier_code', $code)->exists());
        
        return $code;
    }

    public static function generateEmail($firstNameEn, $lastNameEn, $domain = 'bettersystem.co.th')
    {
        $emailUsername = strtolower($firstNameEn . '.' . substr($lastNameEn, 0, 1));
        $email = $emailUsername . '@' . $domain;
        $counter = 1;
        
        while (self::where('email', $email)->exists()) {
            $email = $emailUsername . $counter . '@' . $domain;
            $counter++;
        }
        
        return $email;
    }

    public static function generateExpressUsername($firstNameEn, $lastNameEn)
    {
        $baseUsername = strtolower(substr($firstNameEn, 0, 4) . substr($lastNameEn, 0, 3));
        $username = str_pad($baseUsername, 7, 'x');
        $counter = 1;
        
        while (self::where('express_username', $username)->exists()) {
            $username = substr($baseUsername, 0, 6) . $counter;
            $counter++;
        }
        
        return $username;
    }

    public static function generateExpressCode()
    {
        do {
            $code = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
        } while (self::where('express_code', $code)->exists());
        
        return $code;
    }
}
