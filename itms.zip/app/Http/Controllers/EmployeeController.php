<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Http\Requests\EmployeeRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Hash;

class EmployeeController
{
    /**
     * แสดงรายการพนักงานทั้งหมด
     */
    public function index(Request $request)
    {
        $query = Employee::query();

        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('employee_code', 'like', "%{$search}%")
                  ->orWhere('keycard_id', 'like', "%{$search}%")
                  ->orWhere('first_name_th', 'like', "%{$search}%")
                  ->orWhere('last_name_th', 'like', "%{$search}%")
                  ->orWhere('first_name_en', 'like', "%{$search}%")
                  ->orWhere('last_name_en', 'like', "%{$search}%")
                  ->orWhere('nickname', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('username', 'like', "%{$search}%")
                  // รองรับข้อมูลเก่า
                  ->orWhere('employee_id', 'like', "%{$search}%")
                  ->orWhere('name', 'like', "%{$search}%");
            });
        }

        // Filter by department
        if ($request->filled('department')) {
            $query->where(function($q) use ($request) {
                $q->where('department_id', $request->department)
                  ->orWhere('department', $request->department);
            });
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by role
        if ($request->filled('role')) {
            $query->where('role', $request->role);
        }

        // สำหรับ Ajax DataTables
        if ($request->ajax()) {
            $employees = $query->orderBy('created_at', 'desc')->get();
            
            return response()->json([
                'data' => $employees->map(function ($employee) {
                    return [
                        'id' => $employee->id,
                        'employee_code' => $employee->employee_code ?? $employee->employee_id,
                        'full_name_th' => $employee->full_name_th,
                        'full_name_en' => $employee->full_name_en,
                        'email' => $employee->email,
                        'username' => $employee->username,
                        'department' => $employee->department_name,
                        'status' => $employee->status,
                        'role' => $employee->role,
                        'actions' => $this->getActionButtons($employee)
                    ];
                })
            ]);
        }

        $employees = $query->orderBy('created_at', 'desc')->paginate(15);
        
        return view('employees.index', [
            'employees' => $employees,
            'departments' => Employee::getDepartments(),
            'statuses' => Employee::getStatuses(),
            'roles' => Employee::getRoles(),
            'request' => $request
        ]);
    }

    /**
     * แสดงฟอร์มสร้างพนักงานใหม่
     */
    public function create()
    {
        return view('employees.create', [
            'departments' => Employee::getDepartments(),
            'statuses' => Employee::getStatuses(),
            'roles' => Employee::getRoles(),
            'emailDomains' => Employee::getEmailDomains(),
        ]);
    }

    /**
     * บันทึกพนักงานใหม่
     */
    public function store(EmployeeRequest $request)
    {
        try {
            DB::beginTransaction();

            $data = $request->validated();
            
            // Auto-generate ข้อมูลที่ขาดหาย
            if (empty($data['employee_code'])) {
                $data['employee_code'] = Employee::generateEmployeeCode();
            }
            
            if (empty($data['keycard_id'])) {
                $data['keycard_id'] = Employee::generateKeycardId();
            }
            
            if (empty($data['username']) && !empty($data['first_name_en']) && !empty($data['last_name_en'])) {
                $data['username'] = Employee::generateUsername($data['first_name_en'], $data['last_name_en']);
            }
            
            if (empty($data['email']) && !empty($data['first_name_en']) && !empty($data['last_name_en'])) {
                $domain = $request->get('email_domain', 'bettersystem.co.th');
                $data['email'] = Employee::generateEmail($data['first_name_en'], $data['last_name_en'], $domain);
            }
            
            if (empty($data['computer_password'])) {
                $data['computer_password'] = Employee::generatePassword();
            }
            
            if (empty($data['email_password'])) {
                $data['email_password'] = Employee::generatePassword();
            }
            
            if (empty($data['password'])) {
                $data['password'] = Employee::generatePassword();
            }
            
            if (empty($data['copier_code'])) {
                $data['copier_code'] = Employee::generateCopierCode();
            }
            
            if (empty($data['express_username']) && !empty($data['first_name_en']) && !empty($data['last_name_en'])) {
                $data['express_username'] = Employee::generateExpressUsername($data['first_name_en'], $data['last_name_en']);
            }
            
            if (empty($data['express_code'])) {
                $data['express_code'] = Employee::generateExpressCode();
            }

            // สร้าง backward compatibility data
            if (!empty($data['first_name_th']) && !empty($data['last_name_th'])) {
                $data['name'] = $data['first_name_th'] . ' ' . $data['last_name_th'];
            }

            // Hash password สำหรับ login
            if (!empty($data['password'])) {
                $data['password'] = Hash::make($data['password']);
            }

            // สร้างพนักงานใหม่
            $employee = Employee::create($data);

            DB::commit();

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'เพิ่มข้อมูลพนักงานเรียบร้อยแล้ว',
                    'employee' => $employee,
                    'redirect' => route('employees.index')
                ]);
            }

            return redirect()->route('employees.index')
                           ->with('success', 'เพิ่มข้อมูลพนักงานเรียบร้อยแล้ว');

        } catch (\Exception $e) {
            DB::rollback();
            
            \Log::error('Employee creation failed: ' . $e->getMessage(), [
                'data' => $data ?? [],
                'trace' => $e->getTraceAsString()
            ]);
            
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()
                ], 422);
            }

            return redirect()->back()
                           ->withInput()
                           ->with('error', 'เกิดข้อผิดพลาด: ' . $e->getMessage());
        }
    }

    /**
     * แสดงรายละเอียดพนักงาน
     */
    public function show(Employee $employee)
    {
        return view('employees.show', compact('employee'));
    }

    /**
     * แสดงฟอร์มแก้ไขพนักงาน
     */
    public function edit(Employee $employee)
    {
        return view('employees.edit', [
            'employee' => $employee,
            'departments' => Employee::getDepartments(),
            'statuses' => Employee::getStatuses(),
            'roles' => Employee::getRoles(),
            'emailDomains' => Employee::getEmailDomains(),
        ]);
    }

    /**
     * อัปเดตข้อมูลพนักงาน
     */
    public function update(EmployeeRequest $request, Employee $employee)
    {
        try {
            DB::beginTransaction();

            $data = $request->validated();
            
            // ไม่อัปเดต password ถ้าไม่ได้กรอกใหม่
            if (empty($data['password'])) {
                unset($data['password']);
            } else {
                $data['password'] = Hash::make($data['password']);
            }

            // อัปเดต backward compatibility data
            if (!empty($data['first_name_th']) && !empty($data['last_name_th'])) {
                $data['name'] = $data['first_name_th'] . ' ' . $data['last_name_th'];
            }

            $employee->update($data);

            DB::commit();

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'อัปเดตข้อมูลพนักงานเรียบร้อยแล้ว',
                    'employee' => $employee->fresh(),
                    'redirect' => route('employees.index')
                ]);
            }

            return redirect()->route('employees.index')
                           ->with('success', 'อัปเดตข้อมูลพนักงานเรียบร้อยแล้ว');

        } catch (\Exception $e) {
            DB::rollback();
            
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()
                ], 422);
            }

            return redirect()->back()
                           ->withInput()
                           ->with('error', 'เกิดข้อผิดพลาด: ' . $e->getMessage());
        }
    }

    /**
     * ลบพนักงาน (Soft Delete)
     */
    public function destroy(Employee $employee)
    {
        try {
            $employee->delete();

            if (request()->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'ลบข้อมูลพนักงานเรียบร้อยแล้ว'
                ]);
            }

            return redirect()->route('employees.index')
                           ->with('success', 'ลบข้อมูลพนักงานเรียบร้อยแล้ว');

        } catch (\Exception $e) {
            if (request()->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()
                ], 422);
            }

            return redirect()->back()
                           ->with('error', 'เกิดข้อผิดพลาด: ' . $e->getMessage());
        }
    }

    /**
     * เรียกคืนพนักงานที่ถูกลบ
     */
    public function restore($id)
    {
        try {
            $employee = Employee::withTrashed()->findOrFail($id);
            $employee->restore();

            return response()->json([
                'success' => true,
                'message' => 'เรียกคืนข้อมูลพนักงานเรียบร้อยแล้ว'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()
            ], 422);
        }
    }

    /**
     * ลบพนักงานถาวร
     */
    public function forceDelete($id)
    {
        try {
            $employee = Employee::withTrashed()->findOrFail($id);
            $employee->forceDelete();

            return response()->json([
                'success' => true,
                'message' => 'ลบข้อมูลพนักงานถาวรเรียบร้อยแล้ว'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()
            ], 422);
        }
    }

    /**
     * ส่งออกข้อมูลเป็น Excel
     */
    public function exportExcel(Request $request)
    {
        $query = Employee::query();

        // Apply same filters as index
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('employee_code', 'like', "%{$search}%")
                  ->orWhere('first_name_th', 'like', "%{$search}%")
                  ->orWhere('last_name_th', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        if ($request->filled('department')) {
            $query->where(function($q) use ($request) {
                $q->where('department_id', $request->department)
                  ->orWhere('department', $request->department);
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('role')) {
            $query->where('role', $request->role);
        }

        $employees = $query->orderBy('employee_code')->get();

        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="employees_' . date('Y-m-d_H-i-s') . '.csv"',
        ];

        $callback = function() use ($employees) {
            $file = fopen('php://output', 'w');
            
            // เขียน BOM สำหรับ UTF-8
            fputs($file, "\xEF\xBB\xBF");
            
            // Header
            fputcsv($file, [
                'รหัสพนักงาน',
                'ID Keycard',
                'ชื่อ-นามสกุล (ไทย)',
                'ชื่อ-นามสกุล (อังกฤษ)',
                'ชื่อเล่น',
                'Username',
                'อีเมล',
                'แผนก',
                'สถานะ',
                'บทบาท',
                'รหัสเครื่องถ่าย',
                'Express Username'
            ]);

            // Data
            foreach ($employees as $employee) {
                fputcsv($file, [
                    $employee->employee_code ?? $employee->employee_id,
                    $employee->keycard_id,
                    $employee->full_name_th,
                    $employee->full_name_en,
                    $employee->nickname,
                    $employee->username,
                    $employee->email,
                    $employee->department_name,
                    $employee->status,
                    $employee->role,
                    $employee->copier_code,
                    $employee->express_username
                ]);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    /**
     * สร้างข้อมูลอัตโนมัติ - อัปเดตแบบสมบูรณ์
     */
    public function generateData(Request $request)
    {
        $type = $request->get('type');
        $firstNameEn = $request->get('first_name_en');
        $lastNameEn = $request->get('last_name_en');
        $domain = $request->get('domain', 'bettersystem.co.th');

        $data = [];

        try {
            switch ($type) {
                case 'employee_code':
                    $data['employee_code'] = Employee::generateEmployeeCode();
                    break;
                    
                case 'keycard_id':
                    $data['keycard_id'] = Employee::generateKeycardId();
                    break;
                    
                case 'username':
                    if ($firstNameEn && $lastNameEn) {
                        $data['username'] = Employee::generateUsername($firstNameEn, $lastNameEn);
                    }
                    break;
                    
                case 'email':
                    if ($firstNameEn && $lastNameEn) {
                        $data['email'] = Employee::generateEmail($firstNameEn, $lastNameEn, $domain);
                    }
                    break;
                    
                case 'password':
                case 'computer_password':
                case 'email_password':
                    $data['password'] = Employee::generatePassword();
                    break;
                    
                case 'copier_code':
                    $data['copier_code'] = Employee::generateCopierCode();
                    break;
                    
                case 'express_username':
                    if ($firstNameEn && $lastNameEn) {
                        $data['express_username'] = Employee::generateExpressUsername($firstNameEn, $lastNameEn);
                    }
                    break;
                    
                case 'express_code':
                    $data['express_code'] = Employee::generateExpressCode();
                    break;
                    
                case 'all_computer':
                    if ($firstNameEn && $lastNameEn) {
                        $data['username'] = Employee::generateUsername($firstNameEn, $lastNameEn);
                    }
                    $data['computer_password'] = Employee::generatePassword();
                    $data['copier_code'] = Employee::generateCopierCode();
                    break;
                    
                case 'all':
                    // Generate ทุกอย่าง
                    $data['employee_code'] = Employee::generateEmployeeCode();
                    $data['keycard_id'] = Employee::generateKeycardId();
                    
                    if ($firstNameEn && $lastNameEn) {
                        $data['username'] = Employee::generateUsername($firstNameEn, $lastNameEn);
                        $data['email'] = Employee::generateEmail($firstNameEn, $lastNameEn, $domain);
                        $data['express_username'] = Employee::generateExpressUsername($firstNameEn, $lastNameEn);
                    }
                    
                    $data['computer_password'] = Employee::generatePassword();
                    $data['email_password'] = Employee::generatePassword();
                    $data['password'] = Employee::generatePassword();
                    $data['copier_code'] = Employee::generateCopierCode();
                    $data['express_code'] = Employee::generateExpressCode();
                    break;
                    
                default:
                    return response()->json([
                        'success' => false,
                        'message' => 'Invalid generation type'
                    ], 400);
            }

            return response()->json([
                'success' => true,
                'data' => $data
            ]);

        } catch (\Exception $e) {
            \Log::error('Generate data failed: ' . $e->getMessage(), [
                'type' => $type,
                'params' => $request->all()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'เกิดข้อผิดพลาดในการสร้างข้อมูล: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * สร้างปุ่ม actions สำหรับ DataTable
     */
    private function getActionButtons($employee)
    {
        $buttons = '';
        
        // View button
        $buttons .= '<a href="' . route('employees.show', $employee) . '" class="btn btn-sm btn-info me-1" title="ดูรายละเอียด">
                        <i class="fas fa-eye"></i>
                     </a>';
        
        // Edit button
        $buttons .= '<a href="' . route('employees.edit', $employee) . '" class="btn btn-sm btn-warning me-1" title="แก้ไข">
                        <i class="fas fa-edit"></i>
                     </a>';
        
        // Delete button
        $buttons .= '<button class="btn btn-sm btn-danger delete-btn" data-id="' . $employee->id . '" data-name="' . $employee->full_name_th . '" title="ลบ">
                        <i class="fas fa-trash"></i>
                     </button>';

        return $buttons;
    }
}
