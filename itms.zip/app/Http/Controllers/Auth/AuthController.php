<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use App\Models\Employee;

class AuthController extends Controller
{
    /**
     * แสดงหน้า login
     */
    public function showLoginForm()
    {
        return view('auth.login');
    }

    /**
     * ประมวลผล login สำหรับ web form
     */
    public function loginWeb(Request $request)
    {
        return $this->login($request);
    }

    /**
     * ประมวลผล login
     */
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        // Rate limiting key
        $key = 'login.' . $request->ip();

        // ลองล็อกอินด้วย email/password
        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            
            // ✅ ข้าม status/is_active check ทั้งหมด เพื่อให้ login ได้
            // ลบการตรวจสอบ is_active ออกทั้งหมด
            
            $request->session()->regenerate();

            // Clear rate limiting on successful login
            RateLimiter::clear($key);

            // Update last login
            $user->updateLastLogin();

            // Create API token with role-based expiration
            $tokenExpiry = $user->isAdmin() ? now()->addHours(8) : now()->addHours(4);
            $token = $user->createToken('API Token', ['*'], $tokenExpiry)->plainTextToken;

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Login successful',
                    'user' => $this->formatUserResponse($user),
                    'token' => $token,
                    'redirect' => $this->redirectTo()
                ]);
            }

            return redirect()->intended($this->redirectTo());
        }

        // Rate limiting on failed attempts
        RateLimiter::hit($key, 300); // 5 minutes

        if ($request->ajax()) {
            return $this->sendError('Invalid credentials', [], 401);
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);
    }

    /**
     * Logout สำหรับ web form
     */
    public function logoutWeb(Request $request)
    {
        return $this->logout($request);
    }

    /**
     * Logout
     */
    public function logout(Request $request)
    {
        // Revoke current token if exists
        if ($request->user() && method_exists($request->user(), 'currentAccessToken')) {
            $request->user()->currentAccessToken()->delete();
        }

        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Logged out successfully'
            ]);
        }

        return redirect('/login');
    }

    /**
     * หน้าที่จะ redirect หลัง login สำเร็จ
     */
    protected function redirectTo()
    {
        // ให้ทุกคนไปหน้า dashboard เดียวกัน แล้วแสดงเมนูตาม role
        return '/dashboard';
    }

    /**
     * Format user response for API
     */
    private function formatUserResponse($user)
    {
        return [
            'id' => $user->id,
            'employee_id' => $user->employee_id,
            'full_name' => $user->full_name,
            'email' => $user->email,
            'role' => $user->role,
            'role_text' => $user->role_text,
            'department' => $user->department,
            'department_text' => $user->department_text,
            'position' => $user->position,
        ];
    }

    /**
     * ส่ง error response สำหรับ AJAX
     */
    private function sendError($message, $data = [], $code = 400)
    {
        return response()->json([
            'success' => false,
            'message' => $message,
            'data' => $data
        ], $code);
    }
}
