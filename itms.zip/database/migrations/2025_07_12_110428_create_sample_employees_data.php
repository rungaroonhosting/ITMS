<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

return new class extends Migration
{
    public function up(): void
    {
        // ตรวจสอบว่ามี column employee_id หรือไม่
        $hasEmployeeId = Schema::hasColumn('employees', 'employee_id');
        
        // สร้างข้อมูลพนักงานตัวอย่าง
        $employees = [
            [
                'employee_code' => 'SUPER999',
                'keycard_id' => 'KC999999',
                'first_name_th' => 'ผู้ดูแลระบบ',
                'last_name_th' => 'สูงสุด',
                'first_name_en' => 'Super',
                'last_name_en' => 'Admin',
                'nickname' => 'Admin',
                'username' => 'super.admin',
                'computer_password' => 'Admin123!@#',
                'copier_code' => '9999',
                'email' => 'admin@bettersystem.co.th',
                'email_password' => 'Email123!@#',
                'department_id' => 1,
                'express_username' => 'superadm',
                'express_code' => '9999',
                'can_print_color' => true,
                'can_use_vpn' => true,
                'status' => 'active',
                'role' => 'super_admin',
                'password' => Hash::make('password123'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'employee_code' => 'MGR001',
                'keycard_id' => 'KC100001',
                'first_name_th' => 'จัดการ',
                'last_name_th' => 'ระบบ',
                'first_name_en' => 'IT',
                'last_name_en' => 'Manager',
                'nickname' => 'Manager',
                'username' => 'it.manager',
                'computer_password' => 'Manager123!',
                'copier_code' => '1001',
                'email' => 'manager@bettersystem.co.th',
                'email_password' => 'Email123!',
                'department_id' => 1,
                'express_username' => 'itmgr01',
                'express_code' => '1001',
                'can_print_color' => true,
                'can_use_vpn' => true,
                'status' => 'active',
                'role' => 'it_admin',
                'password' => Hash::make('password123'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'employee_code' => 'EMP001',
                'keycard_id' => 'KC200001',
                'first_name_th' => 'พนักงาน',
                'last_name_th' => 'ตัวอย่าง',
                'first_name_en' => 'Staff',
                'last_name_en' => 'Employee',
                'nickname' => 'Staff',
                'username' => 'staff.employee',
                'computer_password' => 'Staff123!',
                'copier_code' => '2001',
                'email' => 'employee@bettersystem.co.th',
                'email_password' => 'Email123!',
                'department_id' => 1,
                'express_username' => 'stfemp1',
                'express_code' => '2001',
                'can_print_color' => false,
                'can_use_vpn' => false,
                'status' => 'active',
                'role' => 'employee',
                'password' => Hash::make('password123'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
        ];

        // เพิ่ม employee_id ถ้าจำเป็น
        if ($hasEmployeeId) {
            $employees[0]['employee_id'] = 'SUPER999';
            $employees[1]['employee_id'] = 'MGR001'; 
            $employees[2]['employee_id'] = 'EMP001';
        }

        // เพิ่มข้อมูลเดิมที่อาจขาด (สำหรับ backward compatibility)
        foreach ($employees as &$employee) {
            // เพิ่ม name field สำหรับความเข้ากันได้
            $employee['name'] = $employee['first_name_th'] . ' ' . $employee['last_name_th'];
            
            // เพิ่ม department field (string) สำหรับความเข้ากันได้
            $employee['department'] = 'แผนกเทคโนโลยีสารสนเทศ';
        }

        // อัปเดตหรือสร้างข้อมูลพนักงาน
        foreach ($employees as $employee) {
            try {
                DB::table('employees')->updateOrInsert(
                    ['email' => $employee['email']], // เงื่อนไขการค้นหา
                    $employee // ข้อมูลที่จะอัปเดตหรือสร้างใหม่
                );
            } catch (\Exception $e) {
                // หากเกิดข้อผิดพลาด ให้ลองแทรกข้อมูลทีละ field
                $this->insertEmployeeSafely($employee);
            }
        }
    }

    public function down(): void
    {
        // ลบข้อมูลตัวอย่าง
        $emails = [
            'admin@bettersystem.co.th',
            'manager@bettersystem.co.th', 
            'employee@bettersystem.co.th'
        ];
        
        DB::table('employees')->whereIn('email', $emails)->delete();
    }

    private function insertEmployeeSafely($employee)
    {
        try {
            // ลองแทรกข้อมูลพื้นฐานก่อน
            $basicEmployee = [
                'email' => $employee['email'],
                'password' => $employee['password'],
                'status' => $employee['status'],
                'role' => $employee['role'],
                'created_at' => $employee['created_at'],
                'updated_at' => $employee['updated_at'],
            ];

            // เพิ่ม employee_id หรือ name ถ้าจำเป็น
            if (Schema::hasColumn('employees', 'employee_id')) {
                $basicEmployee['employee_id'] = $employee['employee_id'] ?? $employee['employee_code'];
            }
            
            if (Schema::hasColumn('employees', 'name')) {
                $basicEmployee['name'] = $employee['name'];
            }

            $employeeId = DB::table('employees')->insertGetId($basicEmployee);

            // อัปเดตข้อมูลเพิ่มเติมทีละส่วน
            $updateData = [];
            $fieldsToUpdate = [
                'employee_code', 'keycard_id', 'first_name_th', 'last_name_th',
                'first_name_en', 'last_name_en', 'nickname', 'username', 
                'computer_password', 'copier_code', 'email_password', 
                'department_id', 'express_username', 'express_code', 
                'can_print_color', 'can_use_vpn', 'department'
            ];

            foreach ($fieldsToUpdate as $field) {
                if (Schema::hasColumn('employees', $field) && isset($employee[$field])) {
                    $updateData[$field] = $employee[$field];
                }
            }

            if (!empty($updateData)) {
                DB::table('employees')->where('id', $employeeId)->update($updateData);
            }

        } catch (\Exception $e) {
            // หากยังไม่สำเร็จ ข้ามไป
            \Log::warning("Failed to insert employee: " . $employee['email'] . " Error: " . $e->getMessage());
        }
    }
};
