<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('employees', function (Blueprint $table) {
            // ตรวจสอบและเพิ่ม columns ใหม่เฉพาะที่ยังไม่มี
            
            // รหัสพนักงานและ keycard
            if (!Schema::hasColumn('employees', 'employee_code')) {
                $table->string('employee_code')->nullable()->after('id');
            }
            if (!Schema::hasColumn('employees', 'keycard_id')) {
                $table->string('keycard_id')->nullable()->after('employee_code');
            }
            
            // ชื่อ-นามสกุล ภาษาไทย
            if (!Schema::hasColumn('employees', 'first_name_th')) {
                $table->string('first_name_th')->nullable()->after('keycard_id');
            }
            if (!Schema::hasColumn('employees', 'last_name_th')) {
                $table->string('last_name_th')->nullable()->after('first_name_th');
            }
            
            // ชื่อ-นามสกุล ภาษาอังกฤษ
            if (!Schema::hasColumn('employees', 'first_name_en')) {
                $table->string('first_name_en')->nullable()->after('last_name_th');
            }
            if (!Schema::hasColumn('employees', 'last_name_en')) {
                $table->string('last_name_en')->nullable()->after('first_name_en');
            }
            
            // ชื่อเล่น
            if (!Schema::hasColumn('employees', 'nickname')) {
                $table->string('nickname')->nullable()->after('last_name_en');
            }
            
            // ข้อมูลระบบคอมพิวเตอร์
            if (!Schema::hasColumn('employees', 'username')) {
                $table->string('username')->nullable()->after('nickname');
            }
            if (!Schema::hasColumn('employees', 'computer_password')) {
                $table->string('computer_password')->nullable()->after('username');
            }
            if (!Schema::hasColumn('employees', 'copier_code')) {
                $table->string('copier_code', 4)->nullable()->after('computer_password');
            }
            
            // รหัสผ่านอีเมล
            if (!Schema::hasColumn('employees', 'email_password')) {
                $table->string('email_password')->nullable()->after('email');
            }
            
            // แผนกการทำงาน
            if (!Schema::hasColumn('employees', 'department_id')) {
                $table->unsignedBigInteger('department_id')->nullable()->after('email_password');
            }
            
            // Express Program
            if (!Schema::hasColumn('employees', 'express_username')) {
                $table->string('express_username', 7)->nullable()->after('department_id');
            }
            if (!Schema::hasColumn('employees', 'express_code')) {
                $table->string('express_code', 4)->nullable()->after('express_username');
            }
            
            // สิทธิ์การใช้งาน
            if (!Schema::hasColumn('employees', 'can_print_color')) {
                $table->boolean('can_print_color')->default(false)->after('express_code');
            }
            if (!Schema::hasColumn('employees', 'can_use_vpn')) {
                $table->boolean('can_use_vpn')->default(false)->after('can_print_color');
            }
            
            // เพิ่ม password สำหรับ login ระบบ
            if (!Schema::hasColumn('employees', 'password')) {
                $table->string('password')->nullable()->after('can_use_vpn');
            }
            
            // แก้ไข employee_id ให้เป็น nullable หรือมี default value
            if (Schema::hasColumn('employees', 'employee_id')) {
                $table->string('employee_id')->nullable()->change();
            }
        });

        // เพิ่ม foreign key constraint
        try {
            Schema::table('employees', function (Blueprint $table) {
                if (Schema::hasColumn('employees', 'department_id')) {
                    $table->foreign('department_id')->references('id')->on('departments')->onDelete('set null');
                }
            });
        } catch (\Exception $e) {
            // Ignore if foreign key already exists
        }

        // เพิ่ม unique constraints
        $this->addUniqueConstraints();
    }

    public function down(): void
    {
        Schema::table('employees', function (Blueprint $table) {
            // ลบ foreign key
            try {
                $table->dropForeign(['department_id']);
            } catch (\Exception $e) {
                // Ignore if doesn't exist
            }
            
            // ลบ unique constraints
            try {
                $table->dropUnique(['employee_code']);
                $table->dropUnique(['keycard_id']);
                $table->dropUnique(['username']);
            } catch (\Exception $e) {
                // Ignore if doesn't exist
            }
            
            // ลบ columns ที่เพิ่มใหม่
            $columnsToRemove = [
                'employee_code', 'keycard_id', 'first_name_th', 'last_name_th', 
                'first_name_en', 'last_name_en', 'nickname', 'username', 
                'computer_password', 'copier_code', 'email_password', 
                'department_id', 'express_username', 'express_code', 
                'can_print_color', 'can_use_vpn', 'password'
            ];
            
            foreach ($columnsToRemove as $column) {
                if (Schema::hasColumn('employees', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }

    private function addUniqueConstraints()
    {
        $constraints = [
            'employee_code' => 'employees_employee_code_unique',
            'keycard_id' => 'employees_keycard_id_unique', 
            'username' => 'employees_username_unique'
        ];

        foreach ($constraints as $column => $constraintName) {
            try {
                if (Schema::hasColumn('employees', $column)) {
                    Schema::table('employees', function (Blueprint $table) use ($column) {
                        $table->unique($column);
                    });
                }
            } catch (\Exception $e) {
                // Ignore if constraint already exists
            }
        }
    }
};
