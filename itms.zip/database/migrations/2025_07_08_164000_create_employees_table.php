<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->string('employee_id')->unique()->comment('รหัสพนักงาน');
            $table->string('prefix')->comment('คำนำหน้า');
            $table->string('first_name')->comment('ชื่อ');
            $table->string('last_name')->comment('นามสกุล');
            $table->string('full_name')->comment('ชื่อ-นามสกุล เต็ม');
            $table->string('email')->unique()->comment('อีเมล');
            $table->string('username')->unique()->comment('ชื่อผู้ใช้');
            $table->string('password')->comment('รหัสผ่าน');
            $table->string('phone')->nullable()->comment('เบอร์โทรศัพท์');
            $table->string('department')->comment('แผนก');
            $table->string('position')->comment('ตำแหน่ง');
            $table->date('hire_date')->comment('วันที่เริ่มงาน');
            $table->decimal('salary', 10, 2)->nullable()->comment('เงินเดือน');
            $table->enum('status', ['active', 'inactive', 'terminated'])->default('active')->comment('สถานะ');
            $table->text('address')->nullable()->comment('ที่อยู่');
            $table->string('emergency_contact')->nullable()->comment('ผู้ติดต่อฉุกเฉิน');
            $table->string('emergency_phone')->nullable()->comment('เบอร์ติดต่อฉุกเฉิน');
            $table->enum('role', ['super_admin', 'it_admin', 'employee'])->default('employee')->comment('บทบาท');
            $table->text('notes')->nullable()->comment('หมายเหตุ');
            $table->timestamps();
            $table->softDeletes();

            // สร้าง indexes
            $table->index(['department', 'status']);
            $table->index(['role', 'status']);
            $table->index('hire_date');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employees');
    }
};
